import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

class App extends Component {

  constructor() {
    super();

    this.state = {
      newUser: {
        userName: '',
        userEmail: '',
        userMobile: '',
        userAddress: '',
        userVisit: '',
        userDate: ''
      },
      users : []
    }
  }
  
  handleChange= (event)=>
  {
      event.preventDefault();
      switch(event.target.name)
      {
        case "userName"     :   this.setState({newUser:{...this.state.newUser,userName : event.target.value}})
                                  break;
        case "userEmail"    :   this.setState({newUser:{...this.state.newUser,userEmail : event.target.value}})
                                  break;
        case "userMobile"   :   this.setState({newUser:{...this.state.newUser,userMobile : event.target.value}})
                                  break;
        case "userAddress"  :   this.setState({newUser:{...this.state.newUser,userAddress: event.target.value}})
                                  break;
        case "userVisit"    :   this.setState({newUser:{...this.state.newUser,userVisit : event.target.value}})
                                  break;
        case "userDate"     :   this.setState({newUser:{...this.state.newUser,userDate : event.target.value}})
                                  break;
          
      }
  }

  handleSubmit = (event)=>
  {
    event.preventDefault();
    const ite = this.state.users.slice();
    ite.push(this.state.newUser);
    console.log(ite)
    this.setState({
      users:ite
    })
    // this.setState({
    //   users : arr
    // })
    console.log(this.users);
  }
  render() {
    return (
     
      <div>
        <form onSubmit={this.handleSubmit}>
          <div className="row">
            <div className="col-md-4 col-md-offset-2">
              <label className="control-label"> Customer Registration Form</label>
              
              <div className="form-group">
                <input type="text" name="userName" value={this.state.newUser.userName} onChange={this.handleChange}  className="form-control" placeholder="UserName" />
              </div>
              <div className="form-group">
                <input type="email" name="userEmail" value={this.state.newUser.userEmail} onChange={this.handleChange}  className="form-control" placeholder="E-mail Id"/>
              </div>
              <div className="form-group">
                <input type="number" name="userMobile" value={this.state.newUser.userMobile} onChange={this.handleChange} className="form-control" placeholder="Mobile Number"/>
              </div>
              <div className="form-group">
                <input type="text-area" name="userAddress" value={this.state.newUser.userAddress} onChange={this.handleChange}  className="form-control" placeholder="Address"/>
              </div>
              <div className="form-group">
                <input type="text" name="userVisit" value={this.state.newUser.userVisit} onChange={this.handleChange}  className="form-control" placeholder="Purpose Of Visit" />
              </div>
              <div className="form-group">
                <input type="text" name="userDate" value={this.state.newUser.userDate} onChange={this.handleChange}  className="form-control" placeholder="Date Of Visit"/>
              </div>
              <button className="btn btn-primary " type="submit">Login</button>
            </div>
          </div>
        </form>
      </div>
    );
  }
}

export default App;
