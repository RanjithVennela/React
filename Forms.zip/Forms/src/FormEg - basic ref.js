import React from 'react';

import ReactDOM from 'react-dom';


class AddCityName extends React.Component {
	render(){
        return(
            <form id="add-city" onSubmit={this.addCity.bind(this)}>
                <input type="text" required ref="newItem"/>
                <input type="submit" value="Add City" />
            </form>
        );
    }

    //Custom functions
    addCity(e){
        e.preventDefault();
	console.log(this.refs.newItem.value);
       // this.props.onAdd(this.refs.newItem.value);
    }
}

export default AddCityName;

