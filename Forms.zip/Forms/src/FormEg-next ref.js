import React from 'react';


class AddCityName extends React.Component {
	
	constructor() {
		super();
		this.state = {
			uName : '',
			pwd : '',
			check : false
		}
	}
	
	handleChange = (event) =>
	{
		event.preventDefault();
		if(event.target.name === 'uName')
		{
			this.setState({
				uName : event.target.value
			})
		}
		else
		{
			this.setState({
				pwd : event.target.value
			})
		}
		
	}

	handleSubmit = (event)=>
	{
		
		this.setState({
		
			check : true
		})
	}
	handleSign =(event)=>
	{
		
		this.setState({
			uName:'',
			pwd:'',
			check:false
		})
	}
	render() {
		
		if(!this.state.check)
		{
			return(<div>
				<form >
					<input name="uName" value={this.state.uName} type="text" placeholder="Enter UserName" onChange={this.handleChange} />
					<br/>
					<input name="pwd" value={this.state.pwd} type="password" placeholder="Enter Password" onChange={this.handleChange} />
					<br/>
					<input type="submit"  value="Submit" onClick={this.handleSubmit}/>
				</form>
			</div>)
		}
		else
		{
			return (<div>
				WELCOME : <h1> {this.state.uName} </h1>
				<input type="button" value="Signout" onClick={this.handleSign}/>
			</div>)
		}
		}
		
	}

	
export default AddCityName;

