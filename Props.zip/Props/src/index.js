import React from 'react';

import ReactDOM from 'react-dom';


import PropEg from './PropEg';
import imag from './1.jpg';
import imag1 from './2.jpg';
var Movie=[{mName:prompt("Enter first movie", "Default Product"), mTicket:prompt("Enter first movie ticket price"),mImg:imag},
{mName:prompt("Enter Second Name","Default Product"), mTicket:prompt("Enter second movie ticket price"),mImg:imag1}];

ReactDOM.render(<PropEg prod={Movie}/>
	, document.getElementById('root'));



