import React from 'react';

import Main from './Main';


/*4.x introduced some breaking changes, you'll need to import Link from react-router-dom:*/


  
class App extends React.Component {
  render() {
    return (
      <div>
        <Main />
      </div>
    )
  }
}
export default App;


