import React from 'react';
import { Link,Switch } from 'react-router-dom';
import Navigation from './Navigation';
const Samsung = ()=> (<Link to="/Samsung">
    <h1>
        Samsung
    </h1>
    </Link>);

const Iphone = () =>(<div>
    <h1>
        Iphone
    </h1>
    
</div>);

const Nokia = (<div>
    <h1>
        Nokia
    </h1>
   
</div>);
class Main extends React.Component
{
    render()
    {
        return(
            <div>
                <Navigation Sam={Samsung} Nok={Nokia} Ip={Iphone} />
            </div>
        )
    }
} 

export default Main;