import React from 'react';
import {BrowserRouter as Router,Route} from 'react-router-dom';
import { Link,Switch } from 'react-router-dom';

class Navigation extends React.Component
{
    render()
    {
        {console.log(this.props.Sam)}
        return(
            
            <Router>
            <Switch>
                <Route path="/Samsung" component={this.props.Sam} />
                <Route path="/Iphone"  component={this.props.Ip}/>
                <Route path="/Nokia"   component={this.props.Nok}/>
            </Switch>
            </Router>
        )
    }
}

export default Navigation;