import { Component, OnInit } from '@angular/core';
import { Courses } from '../courses';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CourseService } from '../course.service';


@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.css']
})
export class CoursesComponent implements OnInit {
  cDuration:any=null;
  temp:Number=0;
  myForm:FormGroup;
  courseArray:Courses[]=[];
  flag1:boolean=true;
  flag:boolean=true;
  constructor(private fb:FormBuilder, private courseservice:CourseService) {
    this.myForm = this.fb.group({
      courseName:['',Validators.required],
      courseDuration:['',Validators.required]
    })
  }
    
  ngOnInit() {
    this.courseservice.getCourse().subscribe((result:Courses[])=>this.courseArray=result);
  }
 
  AddCourse()
  {
    this.flag1=true;
    this.temp=0;
    if(this.myForm.valid)
    {
      
        this.courseArray.forEach(course=>{
        if(course.courseName.toLowerCase() == this.myForm.get('courseName').value.toLowerCase())
        {
          this.temp=1;
         
        }
      })
      if(this.temp==0)
      {
        this.courseservice.addCourse(this.myForm.value);
        this.courseservice.getCourse().subscribe(result=>this.courseArray=result);
        this.myForm.reset(); 
        this.flag1=true;
      }
      else
      {
        alert("COURSE ALREADY EXISTS. PLEASE ENTER DIFFERENT COURSE")
        this.myForm.reset(); 
      }
     
    }
    else
    {
      this.flag1 = false;
    }
     
  }
  

  getDuration(cName:String)
  {
    this.cDuration="INVALID COURSE";
    this.flag=true;
    console.log(cName);
      if(cName)
      {
        
        this.courseArray.forEach(course =>{
          if((course.courseName).toLowerCase() == cName.toLowerCase())
          { 
            console.log(course.courseName);
            console.log(cName);
             this.flag=true
            // console.log("dfhbfj")

            this.cDuration = "COURSE DURATION IS " + course.courseDuration +" DAYS";
            
            console.log(this.cDuration)
          }
        })
      }
      else
      {
          alert("ENTER COURSE NAME TO GET DURATION");
          this.flag=false
      //   this.cDuration="Course is not prresent"
      }
  }
}